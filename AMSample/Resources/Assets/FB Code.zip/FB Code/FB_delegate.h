//
//  FB_delegate.h
//  Fortune Cookie
//
//  Created by Miles Alden on 4/14/11.
//  Copyright 2011 Santa Cruz Singers. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FBConnect.h"

@class CentralControl;

@interface FB_delegate : NSObject <UIAlertViewDelegate, FBRequestDelegate, FBSessionDelegate> {

	CentralControl *controller;
}


- (id) initWithViewController: (CentralControl *)con;
- (void)fbDidLogin;
- (void)fbDidNotLogin;
- (void)request:(FBRequest *)request didLoad:(id)result;
- (NSString *)socialPostString;

@end
