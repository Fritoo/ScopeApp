//
//  FB_delegate.m
//  Fortune Cookie
//
//  Created by Miles Alden on 4/14/11.
//  Copyright 2011 Santa Cruz Singers. All rights reserved.
//

#import "FB_delegate.h"
#import "Delegate.h"
#import "CentralControl.h"
#import "CookieController.h"
#import "Cookie.h"
#import "BaseViewController.h"
#import "FlurryAPI.h"

@implementation FB_delegate




- (id) initWithViewController: (CentralControl *)con {
	
	self = [super init];
	self->controller = con;
	return self;
	
}


- (void)fbDidLogin
{
	
	//Grab refs
	Delegate *app = APP_DELEGATE;
	Facebook *fb = app.facebook;
	Cookie *cook = controller.baseVCon.cookieCon.cookie;
	
	
	NSString *fortune = ( cook.fortuneOnScreen ) ? cook.fortuneLabel.text : @"Man who stand on toilet get high on pot." ;
	NSString *s = [NSString stringWithFormat:@"%@\n\n%@\n",[self socialPostString], fortune, POST_SUFFIX ];
	NSMutableDictionary* params = [NSMutableDictionary dictionaryWithObjectsAndKeys: 
								   s,  @"message", 
								   FB_PIC, @"picture",
								   FB_PIC_LINK, @"link",
								   nil]; 
	
//	picPath, @"picture",http://www.chromascope.biz/ar/bf_icon.png
//	[fb requestWithMethodName:@"facebook.Stream.publish" andParams:params
//				andHttpMethod:@"POST" andDelegate:self];
//
//	[fb requestWithGraphPath:@"me" andDelegate:self];

	
	
	[fb requestWithGraphPath:@"feed"
				   andParams:params
			   andHttpMethod:@"POST"
				 andDelegate:self];
	
	
	
}




- (NSString *)socialPostString {

	NSString *s;

	int i = arc4random()%4;
	switch (i) {
		case 0:
			s = POST_STRING_0;
			break;
		case 1:
			s = POST_STRING_1;
			break;
		case 2:
			s = POST_STRING_2;
			break;
		case 3:
			s = POST_STRING_3;
			break;
		case 4:
			s = POST_STRING_4;
			break;
		case 5:
			s = POST_STRING_5;
			break;
		default:
			s = POST_STRING_0;
			break;
	}
	
	return s;
	
}



- (void)fbDidNotLogin
{
//	NSLog(@"fbDidNOTLogin");
}

- (void)requestLoading:(FBRequest *)request {

//	printf("\nrequest loading\n");
}

- (void)request:(FBRequest *)request didReceiveResponse:(NSURLResponse *)response {
	
//	printf("\nrequest received response\n");

}

- (void)request:(FBRequest *)request didFailWithError:(NSError *)error {
		
	[FlurryAPI logEvent:@"BADASS_FORTUNE_COOKIE_FAILED_POST_TO_USERS_FB_WALL"];
}



- (void)request:(FBRequest *)request didLoad:(id)result {
	// flurry event
	[FlurryAPI logEvent:@"BADASS_FORTUNE_COOKIE_DID_POST_TO_USERS_FB_WALL"];
	
	
	UIAlertView *alertViewActivate = [[UIAlertView alloc]
									  initWithTitle:@""
									  message:@"Your fortune posted successfully!"
									  delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
	
	[alertViewActivate show];
	[alertViewActivate release];
}


- (void)request:(FBRequest *)request didLoadRawResponse:(NSData *)data {

}

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex {
	
	[controller fbDelegateCompleted];
	
}
	 
	 
@end
